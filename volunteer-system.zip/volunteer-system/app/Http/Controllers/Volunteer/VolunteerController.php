<?php
namespace App\Http\Controllers\Volunteer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Task;
use App\Models\VolunteerHour;

class VolunteerController extends Controller
{
    // 1. عرض لوحة تحكم المتطوع + مهامه
    public function index()
    {
        $user = Auth::user();
        
        // جلب المهام المخصصة لهذا المتطوع
        $myTasks = Task::where('assigned_to', $user->id)
            ->orderBy('created_at', 'desc')
            ->get();
        
        // جلب إجمالي ساعات التطوع
        $totalHours = VolunteerHour::where('user_id', $user->id)->sum('hours');
        
        // عدد المهام المكتملة
        $completedCount = Task::where('assigned_to', $user->id)
            ->where('status', 'completed')
            ->count();
        
        $data = [
            'user' => $user,
            'tasks' => $myTasks,
            'totalHours' => $totalHours,
            'completedCount' => $completedCount
        ];
        
        // دعم الـ API و Blade معاً
        if (request()->wantsJson()) {
            return response()->json($data);
        }
        
        return view('volunteer.dashboard', $data);
    }
    
    // 2. عرض تفاصيل مهمة معينة
    public function showTask($taskId)
    {
        $task = Task::where('id', $taskId)
            ->where('assigned_to', Auth::id())
            ->with(['team.supervisor'])
            ->firstOrFail();
        
        // جلب الساعات المسجلة سابقاً لهذه المهمة
        $loggedHours = VolunteerHour::where('user_id', Auth::id())
            ->where('task_id', $taskId)
            ->get();
        
        $data = [
            'task' => $task,
            'loggedHours' => $loggedHours
        ];
        
        if (request()->wantsJson()) {
            return response()->json($data);
        }
        
        return view('volunteer.task-details', $data);
    }
    
    // 3. تسجيل ساعات التطوع + ملاحظات الإنجاز
    public function storeHours(Request $request, $taskId)
    {
        $request->validate([
            'hours' => 'required|numeric|min:0.5|max:24',
            'notes' => 'nullable|string|max:1000',
            'date' => 'required|date'
        ]);
        
        // التأكد أن المهمة مخصصة لهذا المتطوع
        $task = Task::where('id', $taskId)
            ->where('assigned_to', Auth::id())
            ->firstOrFail();
        
        // تسجيل الساعات في جدول volunteer_hours
        $volunteerHour = VolunteerHour::create([
            'user_id' => Auth::id(),
            'task_id' => $taskId,
            'date' => $request->date,
            'hours' => $request->hours,
            'notes' => $request->notes,
            'approved_by' => null // تنتظر اعتماد المشرف
        ]);
        
        // تحديث حالة المهمة إذا لزم
        if ($task->status === 'pending') {
            $task->update(['status' => 'in_progress']);
        }
        
        $message = 'تم تسجيل ساعات التطوع بنجاح!';
        
        if (request()->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => $message,
                'data' => $volunteerHour
            ], 201);
        }
        
        return redirect()->route('volunteer.dashboard')
            ->with('success', $message);
    }
    
    // 4. عرض تقارير المتطوع الشخصية
    public function myReports()
    {
        $userId = Auth::id();
        
        // إجمالي الساعات
        $totalHours = VolunteerHour::where('user_id', $userId)->sum('hours');
        
        // الساعات المعتمدة فقط
        $approvedHours = VolunteerHour::where('user_id', $userId)
            ->whereNotNull('approved_by')
            ->sum('hours');
        
        // سجل الساعات مفصّل
        $hoursLog = VolunteerHour::where('user_id', $userId)
            ->with(['task'])
            ->orderBy('date', 'desc')
            ->get();
        
        $data = [
            'totalHours' => $totalHours,
            'approvedHours' => $approvedHours,
            'log' => $hoursLog
        ];
        
        if (request()->wantsJson()) {
            return response()->json($data);
        }
        
        return view('volunteer.reports', $data);
    }
}